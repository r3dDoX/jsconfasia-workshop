export const PEOPLE = [
  { firstname: 'Christian', lastname: 'Kohler', office: 'Zürich' },
  { firstname: 'Patrick', lastname: 'Walther', office: 'Zürich' },
  { firstname: 'Stefan', lastname: 'Reichhart', office: 'Bern' },
];

export const ANIMALS = [
  {
    name: "Butters",
    age: 3,
    type: "hamster",
    legs: 4,
  },
  {
    name: "Lizzy",
    age: 6,
    type: "dog",
    legs: 4,
  },
  {
  },
  {
    name: "Red",
    age: 1,
    type: "cat",
    legs: 4,
  },
  {
    name: "Joey",
    age: 7,
    type: "mouse",
    legs: 4,
  },
  {
    name: "Ferdinand",
    age: 1,
    type: "cat",
    legs: 4,
  },
  null,
  {
    name: "Rambo",
    age: 9,
    type: "dog",
    legs: 2,
  },
  {
    name: "Dumbo",
    age: 20,
    type: "elefant",
    legs: 4,
  },
  {
    name: "Homer",
    age: 2,
    type: "hamster",
    legs: 4,
  },
  {
    name: "Sir Lancelot",
    age: 1,
    type: "mouse",
    legs: 4,
  },
  {
    name: "Duke",
    age: 7,
    type: "cat",
    legs: 4,
  },
  {
    name: "Rocky",
    age: 2,
    type: "dog",
    legs: 4,
  },
  {
    name: "Ms Kitty",
    age: 9,
    type: "cat",
    legs: 3,
  },
  {
    name: "Lord Nibbler",
    age: 4,
    type: "mouse",
    legs: 4,
  }
];