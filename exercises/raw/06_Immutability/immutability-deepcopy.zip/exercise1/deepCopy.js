export function deepCopy(object) {
  return object;
};