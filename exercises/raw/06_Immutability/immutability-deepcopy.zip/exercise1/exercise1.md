Exercise 1

- Provide the implementation of deepCopy(object) within deepCopy.js.
- The implementation should be working for all kinds of deeply nested objects. 
- You don't need to write or adapt any test-cases. Everything is provided for you

HINTS: 
- combine array functions and spread operator