import { DATA } from '../mock-data';

describe("playground tests with immutable.js", () => {
  it("your test", () => {
    // TODO
  });
});