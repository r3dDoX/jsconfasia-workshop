Exercises 1 - 12

- Process each exercise and evaluate whether the function of interest is pure or impure. 
- Think of the reasons why the function is pure or impure.

HINTS:
- re-read the definition of a pure function