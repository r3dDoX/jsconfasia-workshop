import { request, action } from "./simulate.js";

export class Service {
  doSomething() {
    // TODO
  }
}
