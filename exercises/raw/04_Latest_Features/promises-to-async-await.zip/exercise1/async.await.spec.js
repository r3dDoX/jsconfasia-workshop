import { Service } from "./asyncawait.js";

describe("chaining mutliple async calls using async/await", () => {
  it("should work", () => {
    console.log("-- start test using Promises --");
    let service = new Service();
    service.doSomething();
    console.log("-- done test using Promises --");
  });
});
