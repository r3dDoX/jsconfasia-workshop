export function min(args) {
  return Math.min(...args);
}